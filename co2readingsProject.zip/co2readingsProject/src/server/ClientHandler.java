import java.io.*;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class ClientHandler implements Runnable {
    private final Socket clientSocket;

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }

    @Override
    public void run() {
        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            // Send welcome message
            out.println("Welcome to the CO2 Data Logger!");

            // Collect data from the client
            out.println("Enter User ID:");
            String userId = in.readLine();

            out.println("Enter Postcode:");
            String postcode = in.readLine();

            out.println("Enter CO2 concentration (ppm):");
            String co2Input = in.readLine();
            float co2ppm = Float.parseFloat(co2Input);

            // Log data with timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            saveToCSV(timestamp, userId, postcode, co2ppm);

            out.println("Data submitted successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error handling client: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.out.println("Error closing client socket: " + e.getMessage());
            }
        }
    }

    private synchronized void saveToCSV(String timestamp, String userId, String postcode, float co2ppm) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(Server.getCsvFile(), true))) {
            writer.write(String.join(",", timestamp, userId, postcode, String.valueOf(co2ppm)));
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error writing to CSV file: " + e.getMessage());
        }
    }

}
