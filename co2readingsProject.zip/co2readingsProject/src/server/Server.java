import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.*;

public class Server {
    private static final int MAX_CLIENTS = 4; // Limit for simultaneous clients
    private static final String CSV_FILE = "co2_data.csv";
    private final int port;

    public Server(int port) {
        this.port = port;
    }

    // Getter method for CSV_FILE
    public static String getCsvFile() {
        return CSV_FILE;
    }

    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server started on port: " + port);

            // Initialize the thread pool to handle client connections
            ExecutorService pool = Executors.newFixedThreadPool(MAX_CLIENTS);

            // Ensure the CSV file has a header line
            initializeCSVFile();

            // Continuously accept new client connections
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected");

                // Handle each client in a separate thread
                pool.execute(new ClientHandler(clientSocket));
            }
        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }

    private void initializeCSVFile() {
        Path path = Paths.get(CSV_FILE);
        if (Files.notExists(path)) {
            try (BufferedWriter writer = Files.newBufferedWriter(path)) {
                writer.write("Timestamp,UserID,Postcode,CO2_ppm");
                writer.newLine();
            } catch (IOException e) {
                System.out.println("Error initializing CSV file: " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 8080;
        Server server = new Server(port);
        server.start();
    }
}
